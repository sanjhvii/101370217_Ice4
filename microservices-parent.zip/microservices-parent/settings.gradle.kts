rootProject.name = "microservices-parent"

include("order-service", "discovery-service", "inventory-service",  "product-service", "api-gateway")
