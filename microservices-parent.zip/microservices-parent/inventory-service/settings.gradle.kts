rootProject.name = "inventory-service"
